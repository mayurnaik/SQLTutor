--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = world, pg_catalog;

ALTER TABLE ONLY world.countrylanguage DROP CONSTRAINT countrylanguage_countrycode_fkey;
ALTER TABLE ONLY world.country DROP CONSTRAINT country_capital_fkey;
SET search_path = sales, pg_catalog;

ALTER TABLE ONLY sales.salesreps DROP CONSTRAINT rep_office_fkey;
ALTER TABLE ONLY sales.customers DROP CONSTRAINT empl_cust_num_fkey;
ALTER TABLE ONLY sales.orders DROP CONSTRAINT cust_num_fkey;
SET search_path = company, pg_catalog;

ALTER TABLE ONLY company.works_on DROP CONSTRAINT works_on_project_id_fkey;
ALTER TABLE ONLY company.works_on DROP CONSTRAINT works_on_employee_ssn_fkey;
ALTER TABLE ONLY company.project DROP CONSTRAINT project_department_id_fkey;
ALTER TABLE ONLY company.employee DROP CONSTRAINT employee_manager_ssn_fkey;
ALTER TABLE ONLY company.employee DROP CONSTRAINT employee_department_id_fkey;
ALTER TABLE ONLY company.dependent DROP CONSTRAINT dependent_employee_ssn_fkey;
ALTER TABLE ONLY company.department DROP CONSTRAINT department_manager_ssn_fkey;
ALTER TABLE ONLY company.department_location DROP CONSTRAINT department_location_department_id_fkey;
SET search_path = booktown, pg_catalog;

ALTER TABLE ONLY booktown.schedules DROP CONSTRAINT valid_employee;
DROP TRIGGER sync_authors_books ON booktown.authors;
DROP TRIGGER check_shipment ON booktown.shipments;
DROP RULE sync_stock_with_editions ON booktown.editions;
SET search_path = sales, pg_catalog;

DROP INDEX sales.fki_rep_office_fkey;
DROP INDEX sales.fki_cust_num_fkey;
SET search_path = jobs, pg_catalog;

DROP INDEX jobs.fki_jobs_jobs_fk_regularuser;
DROP INDEX jobs.fki_jobs_jobs_fk_employer;
SET search_path = booktown, pg_catalog;

DROP INDEX booktown.unique_publisher_idx;
DROP INDEX booktown.text_idx;
DROP INDEX booktown.shipments_ship_id_key;
DROP INDEX booktown.books_title_idx;
SET search_path = world, pg_catalog;

ALTER TABLE ONLY world.countrylanguage DROP CONSTRAINT countrylanguage_pkey;
ALTER TABLE ONLY world.country DROP CONSTRAINT country_pkey;
ALTER TABLE ONLY world.city DROP CONSTRAINT city_pkey;
SET search_path = sales, pg_catalog;

ALTER TABLE ONLY sales.salesreps DROP CONSTRAINT salesreps_pkey;
ALTER TABLE ONLY sales.orders DROP CONSTRAINT order_num_pkey;
ALTER TABLE ONLY sales.offices DROP CONSTRAINT office_pkey;
ALTER TABLE ONLY sales.customers DROP CONSTRAINT cust_num_pkey;
SET search_path = jobs, pg_catalog;

ALTER TABLE ONLY jobs."user" DROP CONSTRAINT jobs_user_pk;
ALTER TABLE ONLY jobs.regularuser DROP CONSTRAINT jobs_regularuser_pk;
ALTER TABLE ONLY jobs.jobs DROP CONSTRAINT jobs_jobs_pk;
ALTER TABLE ONLY jobs.employer DROP CONSTRAINT jobs_employer_pk;
ALTER TABLE ONLY jobs.adminuser DROP CONSTRAINT jobs_adminuser_pk;
SET search_path = company, pg_catalog;

ALTER TABLE ONLY company.works_on DROP CONSTRAINT works_on_ssn_id_pkey;
ALTER TABLE ONLY company.project DROP CONSTRAINT project_name_key;
ALTER TABLE ONLY company.project DROP CONSTRAINT project_id_pkey;
ALTER TABLE ONLY company.employee DROP CONSTRAINT employee_ssn_pkey;
ALTER TABLE ONLY company.dependent DROP CONSTRAINT dependent_ssn_name_pkey;
ALTER TABLE ONLY company.department DROP CONSTRAINT department_name_key;
ALTER TABLE ONLY company.department_location DROP CONSTRAINT department_location_id_location_pkey;
ALTER TABLE ONLY company.department DROP CONSTRAINT department_id_pkey;
SET search_path = booktown, pg_catalog;

ALTER TABLE ONLY booktown.subjects DROP CONSTRAINT subjects_pkey;
ALTER TABLE ONLY booktown.stock DROP CONSTRAINT stock_pkey;
ALTER TABLE ONLY booktown.states DROP CONSTRAINT state_pkey;
ALTER TABLE ONLY booktown.schedules DROP CONSTRAINT schedules_pkey;
ALTER TABLE ONLY booktown.publishers DROP CONSTRAINT publishers_pkey;
ALTER TABLE ONLY booktown.editions DROP CONSTRAINT pkey;
ALTER TABLE ONLY booktown.employees DROP CONSTRAINT employees_pkey;
ALTER TABLE ONLY booktown.customers DROP CONSTRAINT customers_pkey;
ALTER TABLE ONLY booktown.books DROP CONSTRAINT books_id_pkey;
ALTER TABLE ONLY booktown.authors DROP CONSTRAINT authors_pkey;
SET search_path = world, pg_catalog;

SET search_path = sales, pg_catalog;

SET search_path = jobs, pg_catalog;

SET search_path = company, pg_catalog;

SET search_path = booktown, pg_catalog;

SET search_path = world, pg_catalog;

DROP TABLE world.countrylanguage;
DROP TABLE world.country;
DROP TABLE world.city;
SET search_path = sales, pg_catalog;

DROP TABLE sales.salesreps;
DROP TABLE sales.orders;
DROP TABLE sales.offices;
DROP TABLE sales.customers;
SET search_path = jobs, pg_catalog;

DROP TABLE jobs."user";
DROP TABLE jobs.regularuser;
DROP TABLE jobs.jobs;
DROP TABLE jobs.employer;
DROP TABLE jobs.adminuser;
SET search_path = company, pg_catalog;

DROP TABLE company.works_on;
DROP TABLE company.project;
DROP TABLE company.employee;
DROP TABLE company.dependent;
DROP TABLE company.department_location;
DROP TABLE company.department;
SET search_path = booktown, pg_catalog;

DROP TABLE booktown.text_sorting;
DROP TABLE booktown.subjects;
DROP SEQUENCE booktown.subject_ids;
DROP VIEW booktown.stock_view;
DROP TABLE booktown.stock_backup;
DROP TABLE booktown.stock;
DROP TABLE booktown.states;
DROP SEQUENCE booktown.shipments_ship_id_seq;
DROP TABLE booktown.schedules;
DROP VIEW booktown.recent_shipments;
DROP TABLE booktown.shipments;
DROP TABLE booktown.publishers;
DROP TABLE booktown.numeric_values;
DROP TABLE booktown.my_list;
DROP TABLE booktown.money_example;
DROP TABLE booktown.favorite_books;
DROP TABLE booktown.favorite_authors;
DROP TABLE booktown.employees;
DROP TABLE booktown.editions;
DROP TABLE booktown.distinguished_authors;
DROP TABLE booktown.daily_inventory;
DROP TABLE booktown.customers;
DROP TABLE booktown.books;
DROP TABLE booktown.book_queue;
DROP SEQUENCE booktown.book_ids;
DROP TABLE booktown.book_backup;
DROP TABLE booktown.authors;
DROP SEQUENCE booktown.author_ids;
DROP TABLE booktown.alternate_stock;
DROP AGGREGATE booktown.sum(text);
DROP FUNCTION booktown.triple_price(double precision);
DROP FUNCTION booktown.title(integer);
DROP FUNCTION booktown.test_check_a_id();
DROP FUNCTION booktown.test(integer);
DROP FUNCTION booktown.sync_authors_and_books();
DROP FUNCTION booktown.stock_amount(integer, integer);
DROP FUNCTION booktown.ship_item(text, text, text);
DROP FUNCTION booktown.raise_test();
DROP FUNCTION booktown.mixed();
DROP FUNCTION booktown.isbn_to_title(text);
DROP FUNCTION booktown.in_stock(integer, integer);
DROP FUNCTION booktown.html_linebreaks(text);
DROP FUNCTION booktown.givename();
DROP FUNCTION booktown.get_customer_name(integer);
DROP FUNCTION booktown.get_customer_id(text, text);
DROP FUNCTION booktown.get_author(integer);
DROP FUNCTION booktown.get_author(text);
DROP FUNCTION booktown.first();
DROP FUNCTION booktown.extract_title(integer);
DROP FUNCTION booktown.extract_all_titles2();
DROP FUNCTION booktown.extract_all_titles();
DROP FUNCTION booktown.double_price(double precision);
DROP FUNCTION booktown.count_by_two(integer);
DROP FUNCTION booktown.compound_word(text, text);
DROP FUNCTION booktown.check_shipment_addition();
DROP FUNCTION booktown.check_book_addition();
DROP FUNCTION booktown.books_by_subject(text);
DROP FUNCTION booktown.audit_test();
DROP FUNCTION booktown.add_two_loop(integer, integer);
DROP FUNCTION booktown.add_shipment(integer, text);
DROP EXTENSION plpgsql;
DROP SCHEMA world;
DROP SCHEMA sales;
DROP SCHEMA public;
DROP SCHEMA jobs;
DROP SCHEMA company;
DROP SCHEMA booktown;
--
-- Name: booktown; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA booktown;


ALTER SCHEMA booktown OWNER TO postgres;

--
-- Name: company; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA company;


ALTER SCHEMA company OWNER TO postgres;

--
-- Name: jobs; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA jobs;


ALTER SCHEMA jobs OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: readonly
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO readonly;

--
-- Name: sales; Type: SCHEMA; Schema: -; Owner: DB_Manager
--

CREATE SCHEMA sales;


ALTER SCHEMA sales OWNER TO "DB_Manager";

--
-- Name: world; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA world;


ALTER SCHEMA world OWNER TO postgres;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = booktown, pg_catalog;

--
-- Name: add_shipment(integer, text); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION add_shipment(integer, text) RETURNS timestamp with time zone
    LANGUAGE plpgsql
    AS $_$
  DECLARE
    customer_id ALIAS FOR $1;
    isbn ALIAS FOR $2;
    shipment_id INTEGER;
    right_now timestamp;
  BEGIN
    right_now := 'now';
    SELECT INTO shipment_id id FROM shipments ORDER BY id DESC;
    shipment_id := shipment_id + 1;
    INSERT INTO shipments VALUES ( shipment_id, customer_id, isbn, right_now );
    RETURN right_now;
  END;
$_$;


ALTER FUNCTION booktown.add_shipment(integer, text) OWNER TO postgres;

--
-- Name: add_two_loop(integer, integer); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION add_two_loop(integer, integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
  DECLARE
 
     -- Declare aliases for function arguments.
 
    low_number ALIAS FOR $1;
    high_number ALIAS FOR $2;
 
     -- Declare a variable to hold the result.
 
    result INTEGER = 0;
 
  BEGIN
 
    WHILE result != high_number LOOP
      result := result + 1;
    END LOOP;
 
    RETURN result;
  END;
$_$;


ALTER FUNCTION booktown.add_two_loop(integer, integer) OWNER TO postgres;

--
-- Name: audit_test(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION audit_test() RETURNS opaque
    LANGUAGE plpgsql
    AS $$
    BEGIN   
       
      IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN

         NEW.user_aud := current_user;
         NEW.mod_time := 'NOW';

        INSERT INTO inventory_audit SELECT * FROM inventory WHERE prod_id=NEW.prod_id;
              
      RETURN NEW; 

      ELSE if TG_OP = 'DELETE' THEN
        INSERT INTO inventory_audit SELECT *, current_user, 'NOW' FROM inventory WHERE prod_id=OLD.prod_id;

      RETURN OLD;
      END IF;
     END IF;
    END;
$$;


ALTER FUNCTION booktown.audit_test() OWNER TO postgres;

--
-- Name: books_by_subject(text); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION books_by_subject(text) RETURNS text
    LANGUAGE plpgsql
    AS $_$
  DECLARE
    sub_title ALIAS FOR $1;
    sub_id INTEGER;
    found_text TEXT :='';
  BEGIN
      SELECT INTO sub_id id FROM subjects WHERE subject = sub_title;
      RAISE NOTICE 'sub_id = %',sub_id;
      IF sub_title = 'all' THEN
        found_text := extract_all_titles();
        RETURN found_text;
      ELSE IF sub_id  >= 0 THEN
          found_text := extract_title(sub_id);
          RETURN  '
' || sub_title || ':
' || found_text;
        END IF;
    END IF;
    RETURN 'Subject not found.';
  END;
$_$;


ALTER FUNCTION booktown.books_by_subject(text) OWNER TO postgres;

--
-- Name: check_book_addition(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION check_book_addition() RETURNS opaque
    LANGUAGE plpgsql
    AS $$
  DECLARE 
    id_number INTEGER;
    book_isbn TEXT;
  BEGIN

    SELECT INTO id_number id FROM customers WHERE id = NEW.customer_id; 

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Invalid customer ID number.';  
    END IF;

    SELECT INTO book_isbn isbn FROM editions WHERE isbn = NEW.isbn; 

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Invalid ISBN.'; 
    END IF; 

    UPDATE stock SET stock = stock -1 WHERE isbn = NEW.isbn; 

    RETURN NEW; 
  END;
$$;


ALTER FUNCTION booktown.check_book_addition() OWNER TO postgres;

--
-- Name: check_shipment_addition(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION check_shipment_addition() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
     -- Declare a variable to hold the customer ID.
    id_number INTEGER;
 
     -- Declare a variable to hold the ISBN.
    book_isbn TEXT;
  BEGIN
 
     -- If there is an ID number that matches the customer ID in
     -- the new table, retrieve it from the customers table.
    SELECT INTO id_number id FROM customers WHERE id = NEW.customer_id;
 
     -- If there was no matching ID number, raise an exception.
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Invalid customer ID number.';
    END IF;
 
     -- If there is an ISBN that matches the ISBN specified in the
     -- new table, retrieve it from the editions table.
    SELECT INTO book_isbn isbn FROM editions WHERE isbn = NEW.isbn;
 
     -- If there is no matching ISBN, raise an exception.
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Invalid ISBN.';
    END IF;
 
    -- If the previous checks succeeded, update the stock amount
    -- for INSERT commands.
    IF TG_OP = 'INSERT' THEN
       UPDATE stock SET stock = stock -1 WHERE isbn = NEW.isbn;
    END IF;
 
    RETURN NEW;
  END;
$$;


ALTER FUNCTION booktown.check_shipment_addition() OWNER TO postgres;

--
-- Name: compound_word(text, text); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION compound_word(text, text) RETURNS text
    LANGUAGE plpgsql
    AS $_$
     DECLARE
       -- defines an alias name for the two input values
       word1 ALIAS FOR $1;
       word2 ALIAS FOR $2;
     BEGIN
       -- displays the resulting joined words
       RETURN word1 || word2;
     END;
  $_$;


ALTER FUNCTION booktown.compound_word(text, text) OWNER TO postgres;

--
-- Name: count_by_two(integer); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION count_by_two(integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
     DECLARE
          userNum ALIAS FOR $1;
          i integer;
     BEGIN
          i := 1;
          WHILE userNum[1] < 20 LOOP
                i = i+1; 
                return userNum;              
          END LOOP;
          
     END;
   $_$;


ALTER FUNCTION booktown.count_by_two(integer) OWNER TO postgres;

--
-- Name: double_price(double precision); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION double_price(double precision) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$
  DECLARE
  BEGIN
    return $1 * 2;
  END;
$_$;


ALTER FUNCTION booktown.double_price(double precision) OWNER TO postgres;

--
-- Name: extract_all_titles(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION extract_all_titles() RETURNS text
    LANGUAGE plpgsql
    AS $$
  DECLARE
    sub_id INTEGER;
    text_output TEXT = ' ';
    sub_title TEXT;
    row_data books%ROWTYPE;
  BEGIN
    FOR i IN 0..15 LOOP
      SELECT INTO sub_title subject FROM subjects WHERE id = i;
      text_output = text_output || '
' || sub_title || ':
';

      FOR row_data IN SELECT * FROM books
        WHERE subject_id = i  LOOP

        IF NOT FOUND THEN
          text_output := text_output || 'None.
';
        ELSE
          text_output := text_output || row_data.title || '
';
        END IF;

      END LOOP;
    END LOOP;
    RETURN text_output;
  END;
$$;


ALTER FUNCTION booktown.extract_all_titles() OWNER TO postgres;

--
-- Name: extract_all_titles2(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION extract_all_titles2() RETURNS text
    LANGUAGE plpgsql
    AS $$
  DECLARE
    sub_id INTEGER;
    text_output TEXT = ' ';
    sub_title TEXT;
    row_data books%ROWTYPE;
  BEGIN
    FOR i IN 0..15 LOOP
      SELECT INTO sub_title subject FROM subjects WHERE id = i;
      text_output = text_output || '
' || sub_title || ':
';

      FOR row_data IN SELECT * FROM books
        WHERE subject_id = i  LOOP

        text_output := text_output || row_data.title || '
';

      END LOOP;
    END LOOP;
    RETURN text_output;
  END;
$$;


ALTER FUNCTION booktown.extract_all_titles2() OWNER TO postgres;

--
-- Name: extract_title(integer); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION extract_title(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
  DECLARE
    sub_id ALIAS FOR $1;
    text_output TEXT :='
';
    row_data RECORD;
  BEGIN
    FOR row_data IN SELECT * FROM books
    WHERE subject_id = sub_id ORDER BY title  LOOP
      text_output := text_output || row_data.title || '
';
    END LOOP;
    RETURN text_output;
  END;
$_$;


ALTER FUNCTION booktown.extract_title(integer) OWNER TO postgres;

--
-- Name: first(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION first() RETURNS integer
    LANGUAGE plpgsql
    AS $$ 
       DecLarE
        oNe IntEgER := 1;
       bEGiN
        ReTUrn oNE;       
       eNd;
$$;


ALTER FUNCTION booktown.first() OWNER TO postgres;

--
-- Name: get_author(text); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION get_author(text) RETURNS text
    LANGUAGE plpgsql
    AS $_$
  DECLARE
 
      -- Declare an alias for the function argument,
      -- which should be the first name of an author.
     f_name ALIAS FOR $1;
 
       -- Declare a variable with the same type as
       -- the last_name field of the authors table.
     l_name authors.last_name%TYPE;
 
  BEGIN
 
      -- Retrieve the last name of an author from the
      -- authors table whose first name matches the
      -- argument received by the function, and
      -- insert it into the l_name variable.
     SELECT INTO l_name last_name FROM authors WHERE first_name = f_name;
 
       -- Return the first name and last name, separated
       -- by a space.
     return f_name || ' ' || l_name;
 
  END;
$_$;


ALTER FUNCTION booktown.get_author(text) OWNER TO postgres;

--
-- Name: get_author(integer); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION get_author(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
  DECLARE
 
    -- Declare an alias for the function argument,
    -- which should be the id of the author.
    author_id ALIAS FOR $1;
 
    -- Declare a variable that uses the structure of
    -- the authors table.
    found_author authors%ROWTYPE;
 
  BEGIN
 
    -- Retrieve a row of author information for
    -- the author whose id number matches
    -- the argument received by the function.
    SELECT INTO found_author * FROM authors WHERE id = author_id;
 
    -- Return the first
    RETURN found_author.first_name || ' ' || found_author.last_name;
 
  END;
$_$;


ALTER FUNCTION booktown.get_author(integer) OWNER TO postgres;

--
-- Name: get_customer_id(text, text); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION get_customer_id(text, text) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
  DECLARE
 
    -- Declare aliases for user input.
    l_name ALIAS FOR $1;
    f_name ALIAS FOR $2;
 
    -- Declare a variable to hold the customer ID number.
    customer_id INTEGER;
 
  BEGIN
 
    -- Retrieve the customer ID number of the customer whose first and last
    --  name match the values supplied as function arguments.
    SELECT INTO customer_id id FROM customers
      WHERE last_name = l_name AND first_name = f_name;
 
    -- Return the ID number.
    RETURN customer_id;
  END;
$_$;


ALTER FUNCTION booktown.get_customer_id(text, text) OWNER TO postgres;

--
-- Name: get_customer_name(integer); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION get_customer_name(integer) RETURNS text
    LANGUAGE plpgsql
    AS $_$
  DECLARE
  
    -- Declare aliases for user input.
    customer_id ALIAS FOR $1;
    
    -- Declare variables to hold the customer name.
    customer_fname TEXT;
    customer_lname TEXT;
  
  BEGIN
  
    -- Retrieve the customer first and last name for the customer whose
    -- ID matches the value supplied as a function argument.
    SELECT INTO customer_fname, customer_lname 
                first_name, last_name FROM customers
      WHERE id = customer_id;
    
    -- Return the name.
    RETURN customer_fname || ' ' || customer_lname;
  END;
$_$;


ALTER FUNCTION booktown.get_customer_name(integer) OWNER TO postgres;

--
-- Name: givename(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION givename() RETURNS opaque
    LANGUAGE plpgsql
    AS $$
 DECLARE
   tablename text;
 BEGIN
   
   tablename = TG_RELNAME; 
   INSERT INTO INVENTORY values (123, tablename);
   return old;
 END;
$$;


ALTER FUNCTION booktown.givename() OWNER TO postgres;

--
-- Name: html_linebreaks(text); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION html_linebreaks(text) RETURNS text
    LANGUAGE plpgsql
    AS $_$
  DECLARE
    formatted_string text := '';
  BEGIN
    FOR i IN 0 .. length($1) LOOP
      IF substr($1, i, 1) = '
' THEN
        formatted_string := formatted_string || '<br>';
      ELSE
        formatted_string := formatted_string || substr($1, i, 1);
      END IF;
    END LOOP;
    RETURN formatted_string;
  END;
$_$;


ALTER FUNCTION booktown.html_linebreaks(text) OWNER TO postgres;

--
-- Name: in_stock(integer, integer); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION in_stock(integer, integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $_$
  DECLARE
    b_id ALIAS FOR $1;
    b_edition ALIAS FOR $2;
    b_isbn TEXT;
    stock_amount INTEGER;
  BEGIN
     -- This SELECT INTO statement retrieves the ISBN
     -- number of the row in the editions table that had
     -- both the book ID number and edition number that
     -- were provided as function arguments.
    SELECT INTO b_isbn isbn FROM editions WHERE
      book_id = b_id AND edition = b_edition;
 
     -- Check to see if the ISBN number retrieved
     -- is NULL.  This will happen if there is not an
     -- existing book with both the ID number and edition
     -- number specified in the function arguments.
     -- If the ISBN is null, the function returns a
     -- FALSE value and ends.
    IF b_isbn IS NULL THEN
      RETURN FALSE;
    END IF;
 
     -- Retrieve the amount of books available from the
     -- stock table and record the number in the
     -- stock_amount variable.
    SELECT INTO stock_amount stock FROM stock WHERE isbn = b_isbn;
 
     -- Use an IF/THEN/ELSE check to see if the amount
     -- of books available is less than, or equal to 0.
     -- If so, return FALSE.  If not, return TRUE.
    IF stock_amount <= 0 THEN
      RETURN FALSE;
    ELSE
      RETURN TRUE;
    END IF;
  END;
$_$;


ALTER FUNCTION booktown.in_stock(integer, integer) OWNER TO postgres;

--
-- Name: isbn_to_title(text); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION isbn_to_title(text) RETURNS text
    LANGUAGE sql
    AS $_$SELECT title FROM books
                                 JOIN editions AS e (isbn, id)
                                 USING (id)
                                 WHERE isbn = $1$_$;


ALTER FUNCTION booktown.isbn_to_title(text) OWNER TO postgres;

--
-- Name: mixed(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION mixed() RETURNS integer
    LANGUAGE plpgsql
    AS $$
       DecLarE
          --assigns 1 to the oNe variable
          oNe IntEgER 
          := 1;

       bEGiN

          --displays the value of oNe
          ReTUrn oNe;       
       eNd;
       $$;


ALTER FUNCTION booktown.mixed() OWNER TO postgres;

--
-- Name: raise_test(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION raise_test() RETURNS integer
    LANGUAGE plpgsql
    AS $$
  DECLARE
 
     -- Declare an integer variable for testing.
 
    an_integer INTEGER = 1;
 
  BEGIN
 
     -- Raise a debug level message.
 
    RAISE DEBUG 'The raise_test() function began.';
 
    an_integer = an_integer + 1;
 
     -- Raise a notice stating that the an_integer
     -- variable was changed, then raise another notice
     -- stating its new value.
 
    RAISE NOTICE 'Variable an_integer was changed.';
    RAISE NOTICE 'Variable an_integer value is now %.',an_integer;
 
     -- Raise an exception.
 
    RAISE EXCEPTION 'Variable % changed.  Aborting transaction.',an_integer;
 
  END;
$$;


ALTER FUNCTION booktown.raise_test() OWNER TO postgres;

--
-- Name: ship_item(text, text, text); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION ship_item(text, text, text) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
  DECLARE
    l_name ALIAS FOR $1;
    f_name ALIAS FOR $2;
    book_isbn ALIAS FOR $3;
    book_id INTEGER;
    customer_id INTEGER;
 
  BEGIN
 
    SELECT INTO customer_id get_customer_id(l_name,f_name);
 
    IF customer_id = -1 THEN
      RETURN -1;
    END IF;
 
    SELECT INTO book_id book_id FROM editions WHERE isbn = book_isbn;
 
    IF NOT FOUND THEN
      RETURN -1;
    END IF;
 
    PERFORM add_shipment(customer_id,book_isbn);
 
    RETURN 1;
  END;
$_$;


ALTER FUNCTION booktown.ship_item(text, text, text) OWNER TO postgres;

--
-- Name: stock_amount(integer, integer); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION stock_amount(integer, integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
  DECLARE
     -- Declare aliases for function arguments.
    b_id ALIAS FOR $1;
    b_edition ALIAS FOR $2;
     -- Declare variable to store the ISBN number.
    b_isbn TEXT;
     -- Declare variable to store the stock amount.
    stock_amount INTEGER;
  BEGIN
     -- This SELECT INTO statement retrieves the ISBN
     -- number of the row in the editions table that had
     -- both the book ID number and edition number that
     -- were provided as function arguments.
    SELECT INTO b_isbn isbn FROM editions WHERE
      book_id = b_id AND edition = b_edition;
 
     -- Check to see if the ISBN number retrieved
     -- is NULL.  This will happen if there is not an
     -- existing book with both the ID number and edition
     -- number specified in the function arguments.
     -- If the ISBN is null, the function returns a
     -- value of -1 and ends.
    IF b_isbn IS NULL THEN
      RETURN -1;
    END IF;
 
     -- Retrieve the amount of books available from the
     -- stock table and record the number in the
     -- stock_amount variable.
    SELECT INTO stock_amount stock FROM stock WHERE isbn = b_isbn;
 
     -- Return the amount of books available.
    RETURN stock_amount;
  END;
$_$;


ALTER FUNCTION booktown.stock_amount(integer, integer) OWNER TO postgres;

--
-- Name: sync_authors_and_books(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION sync_authors_and_books() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      UPDATE books SET author_id = new.id WHERE author_id = old.id; 
    END IF;
    RETURN new;
  END;
$$;


ALTER FUNCTION booktown.sync_authors_and_books() OWNER TO postgres;

--
-- Name: test(integer); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION test(integer) RETURNS integer
    LANGUAGE plpgsql
    AS $_$
  
 DECLARE 
   -- defines the variable as ALIAS
  variable ALIAS FOR $1;
 BEGIN
  -- displays the variable after multiplying it by two 
  return variable * 2.0;
 END; 
 $_$;


ALTER FUNCTION booktown.test(integer) OWNER TO postgres;

--
-- Name: test_check_a_id(); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION test_check_a_id() RETURNS opaque
    LANGUAGE plpgsql
    AS $$
    BEGIN
     -- checks to make sure the author id
     -- inserted is not left blank or less than 100

        IF NEW.a_id ISNULL THEN
           RAISE EXCEPTION
           'The author id cannot be left blank!';
        ELSE
           IF NEW.a_id < 100 THEN
              RAISE EXCEPTION
              'Please insert a valid author id.';
           ELSE
           RETURN NEW;
           END IF;
        END IF;
    END;
$$;


ALTER FUNCTION booktown.test_check_a_id() OWNER TO postgres;

--
-- Name: title(integer); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION title(integer) RETURNS text
    LANGUAGE sql
    AS $_$SELECT title from books where id = $1$_$;


ALTER FUNCTION booktown.title(integer) OWNER TO postgres;

--
-- Name: triple_price(double precision); Type: FUNCTION; Schema: booktown; Owner: postgres
--

CREATE FUNCTION triple_price(double precision) RETURNS double precision
    LANGUAGE plpgsql
    AS $_$
  DECLARE
     -- Declare input_price as an alias for the
     -- argument variable normally referenced with
     -- the $1 identifier.
    input_price ALIAS FOR $1;
 
  BEGIN
     -- Return the input price multiplied by three.
    RETURN input_price * 3;
  END;
 $_$;


ALTER FUNCTION booktown.triple_price(double precision) OWNER TO postgres;

--
-- Name: sum(text); Type: AGGREGATE; Schema: booktown; Owner: postgres
--

CREATE AGGREGATE sum(text) (
    SFUNC = textcat,
    STYPE = text,
    INITCOND = ''
);


ALTER AGGREGATE booktown.sum(text) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: alternate_stock; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE alternate_stock (
    isbn text,
    cost numeric(5,2),
    retail numeric(5,2),
    stock integer
);


ALTER TABLE booktown.alternate_stock OWNER TO "DB_Manager";

--
-- Name: author_ids; Type: SEQUENCE; Schema: booktown; Owner: postgres
--

CREATE SEQUENCE author_ids
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE booktown.author_ids OWNER TO postgres;

--
-- Name: authors; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE authors (
    id integer NOT NULL,
    last_name text,
    first_name text
);


ALTER TABLE booktown.authors OWNER TO "DB_Manager";

--
-- Name: book_backup; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE book_backup (
    id integer,
    title text,
    author_id integer,
    subject_id integer
);


ALTER TABLE booktown.book_backup OWNER TO "DB_Manager";

--
-- Name: book_ids; Type: SEQUENCE; Schema: booktown; Owner: postgres
--

CREATE SEQUENCE book_ids
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE booktown.book_ids OWNER TO postgres;

--
-- Name: book_queue; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE book_queue (
    title text NOT NULL,
    author_id integer,
    subject_id integer,
    approved boolean
);


ALTER TABLE booktown.book_queue OWNER TO "DB_Manager";

--
-- Name: books; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE books (
    id integer NOT NULL,
    title text NOT NULL,
    author_id integer,
    subject_id integer
);


ALTER TABLE booktown.books OWNER TO "DB_Manager";

--
-- Name: customers; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE customers (
    id integer NOT NULL,
    last_name text,
    first_name text
);


ALTER TABLE booktown.customers OWNER TO "DB_Manager";

--
-- Name: daily_inventory; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE daily_inventory (
    isbn text,
    is_stocked boolean
);


ALTER TABLE booktown.daily_inventory OWNER TO "DB_Manager";

--
-- Name: distinguished_authors; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE distinguished_authors (
    award text
)
INHERITS (authors);


ALTER TABLE booktown.distinguished_authors OWNER TO "DB_Manager";

--
-- Name: editions; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE editions (
    isbn text NOT NULL,
    book_id integer,
    edition integer,
    publisher_id integer,
    publication date,
    type character(1),
    CONSTRAINT integrity CHECK (((book_id IS NOT NULL) AND (edition IS NOT NULL)))
);


ALTER TABLE booktown.editions OWNER TO "DB_Manager";

--
-- Name: employees; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE employees (
    id integer NOT NULL,
    last_name text NOT NULL,
    first_name text,
    CONSTRAINT employees_id CHECK ((id > 100))
);


ALTER TABLE booktown.employees OWNER TO "DB_Manager";

--
-- Name: favorite_authors; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE favorite_authors (
    employee_id integer,
    authors_and_titles text[]
);


ALTER TABLE booktown.favorite_authors OWNER TO "DB_Manager";

--
-- Name: favorite_books; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE favorite_books (
    employee_id integer,
    books text[]
);


ALTER TABLE booktown.favorite_books OWNER TO "DB_Manager";

--
-- Name: money_example; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE money_example (
    money_cash money,
    numeric_cash numeric(6,2)
);


ALTER TABLE booktown.money_example OWNER TO "DB_Manager";

--
-- Name: my_list; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE my_list (
    todos text
);


ALTER TABLE booktown.my_list OWNER TO "DB_Manager";

--
-- Name: numeric_values; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE numeric_values (
    num numeric(30,6)
);


ALTER TABLE booktown.numeric_values OWNER TO "DB_Manager";

--
-- Name: publishers; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE publishers (
    id integer NOT NULL,
    name text,
    address text
);


ALTER TABLE booktown.publishers OWNER TO "DB_Manager";

--
-- Name: shipments; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE shipments (
    id integer DEFAULT nextval(('"shipments_ship_id_seq"'::text)::regclass) NOT NULL,
    customer_id integer,
    isbn text,
    ship_date timestamp with time zone
);


ALTER TABLE booktown.shipments OWNER TO "DB_Manager";

--
-- Name: recent_shipments; Type: VIEW; Schema: booktown; Owner: postgres
--

CREATE VIEW recent_shipments AS
    SELECT count(*) AS num_shipped, max(shipments.ship_date) AS max, b.title FROM ((shipments JOIN editions USING (isbn)) NATURAL JOIN books b(book_id)) GROUP BY b.title ORDER BY count(*) DESC;


ALTER TABLE booktown.recent_shipments OWNER TO postgres;

--
-- Name: schedules; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE schedules (
    employee_id integer NOT NULL,
    schedule text
);


ALTER TABLE booktown.schedules OWNER TO "DB_Manager";

--
-- Name: shipments_ship_id_seq; Type: SEQUENCE; Schema: booktown; Owner: postgres
--

CREATE SEQUENCE shipments_ship_id_seq
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE booktown.shipments_ship_id_seq OWNER TO postgres;

--
-- Name: states; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE states (
    id integer NOT NULL,
    name text,
    abbreviation character(2)
);


ALTER TABLE booktown.states OWNER TO "DB_Manager";

--
-- Name: stock; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE stock (
    isbn text NOT NULL,
    cost numeric(5,2),
    retail numeric(5,2),
    stock integer
);


ALTER TABLE booktown.stock OWNER TO "DB_Manager";

--
-- Name: stock_backup; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE stock_backup (
    isbn text,
    cost numeric(5,2),
    retail numeric(5,2),
    stock integer
);


ALTER TABLE booktown.stock_backup OWNER TO "DB_Manager";

--
-- Name: stock_view; Type: VIEW; Schema: booktown; Owner: postgres
--

CREATE VIEW stock_view AS
    SELECT stock.isbn, stock.retail, stock.stock FROM stock;


ALTER TABLE booktown.stock_view OWNER TO postgres;

--
-- Name: subject_ids; Type: SEQUENCE; Schema: booktown; Owner: postgres
--

CREATE SEQUENCE subject_ids
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 2147483647
    CACHE 1;


ALTER TABLE booktown.subject_ids OWNER TO postgres;

--
-- Name: subjects; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE subjects (
    id integer NOT NULL,
    subject text,
    location text
);


ALTER TABLE booktown.subjects OWNER TO "DB_Manager";

--
-- Name: text_sorting; Type: TABLE; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE text_sorting (
    letter character(1)
);


ALTER TABLE booktown.text_sorting OWNER TO "DB_Manager";

SET search_path = company, pg_catalog;

--
-- Name: department; Type: TABLE; Schema: company; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE department (
    name character varying(15) NOT NULL,
    id integer NOT NULL,
    manager_ssn character(9) DEFAULT '888665555'::bpchar NOT NULL,
    manager_start_date date
);


ALTER TABLE company.department OWNER TO "DB_Manager";

--
-- Name: department_location; Type: TABLE; Schema: company; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE department_location (
    department_id integer NOT NULL,
    location character varying(15) NOT NULL
);


ALTER TABLE company.department_location OWNER TO "DB_Manager";

--
-- Name: dependent; Type: TABLE; Schema: company; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE dependent (
    employee_ssn character(9) NOT NULL,
    name character varying(15) NOT NULL,
    sex character(1),
    birthdate date,
    relationship character varying(8)
);


ALTER TABLE company.dependent OWNER TO "DB_Manager";

--
-- Name: employee; Type: TABLE; Schema: company; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE employee (
    first_name character varying(15) NOT NULL,
    middle_initial character(1),
    last_name character varying(15) NOT NULL,
    ssn character(9) NOT NULL,
    birthdate date,
    address character varying(30),
    sex character(1),
    salary numeric(10,2),
    manager_ssn character(9),
    department_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE company.employee OWNER TO "DB_Manager";

--
-- Name: project; Type: TABLE; Schema: company; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE project (
    name character varying(15) NOT NULL,
    id integer NOT NULL,
    location character varying(15),
    department_id integer NOT NULL
);


ALTER TABLE company.project OWNER TO "DB_Manager";

--
-- Name: works_on; Type: TABLE; Schema: company; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE works_on (
    employee_ssn character(9) NOT NULL,
    project_id integer NOT NULL,
    hours numeric(3,1) NOT NULL
);


ALTER TABLE company.works_on OWNER TO "DB_Manager";

SET search_path = jobs, pg_catalog;

--
-- Name: adminuser; Type: TABLE; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE adminuser (
    email character varying(100) NOT NULL,
    lastlogin date NOT NULL
);


ALTER TABLE jobs.adminuser OWNER TO "DB_Manager";

--
-- Name: employer; Type: TABLE; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE employer (
    empname character varying(50) NOT NULL
);


ALTER TABLE jobs.employer OWNER TO "DB_Manager";

--
-- Name: jobs; Type: TABLE; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE jobs (
    empname character varying(50) NOT NULL,
    email character varying(100) NOT NULL,
    jobtitle character varying(100) NOT NULL
);


ALTER TABLE jobs.jobs OWNER TO "DB_Manager";

--
-- Name: regularuser; Type: TABLE; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE regularuser (
    email character varying(60) NOT NULL,
    birthdate date,
    sex character(1),
    hometown character varying(50),
    currentcity character varying(50)
);


ALTER TABLE jobs.regularuser OWNER TO "DB_Manager";

--
-- Name: user; Type: TABLE; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE "user" (
    email character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    username character varying(50) NOT NULL
);


ALTER TABLE jobs."user" OWNER TO "DB_Manager";

SET search_path = sales, pg_catalog;

--
-- Name: customers; Type: TABLE; Schema: sales; Owner: postgres; Tablespace: 
--

CREATE TABLE customers (
    "CUST_NUM" integer NOT NULL,
    "COMPANY" text NOT NULL,
    "CUST_REP" integer,
    "CREDIT_LIMIT" integer NOT NULL
);


ALTER TABLE sales.customers OWNER TO postgres;

--
-- Name: offices; Type: TABLE; Schema: sales; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE offices (
    "OFFICE" integer NOT NULL,
    "CITY" text NOT NULL,
    "REGION" text NOT NULL,
    "MGR" integer
);


ALTER TABLE sales.offices OWNER TO "DB_Manager";

--
-- Name: orders; Type: TABLE; Schema: sales; Owner: postgres; Tablespace: 
--

CREATE TABLE orders (
    "ORDER_NUM" integer NOT NULL,
    "ORDER_DATE" date NOT NULL,
    "CUST" integer NOT NULL,
    "AMOUNT" integer NOT NULL
);


ALTER TABLE sales.orders OWNER TO postgres;

--
-- Name: salesreps; Type: TABLE; Schema: sales; Owner: postgres; Tablespace: 
--

CREATE TABLE salesreps (
    "EMPL_NUM" integer NOT NULL,
    "NAME" text NOT NULL,
    "AGE" integer NOT NULL,
    "REP_OFFICE" integer NOT NULL,
    "TITLE" text NOT NULL
);


ALTER TABLE sales.salesreps OWNER TO postgres;

SET search_path = world, pg_catalog;

--
-- Name: city; Type: TABLE; Schema: world; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE city (
    id integer NOT NULL,
    name text NOT NULL,
    countrycode character(3) NOT NULL,
    district text NOT NULL,
    population integer NOT NULL
);


ALTER TABLE world.city OWNER TO "DB_Manager";

--
-- Name: country; Type: TABLE; Schema: world; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE country (
    code character(3) NOT NULL,
    name text NOT NULL,
    continent text NOT NULL,
    region text NOT NULL,
    surfacearea real NOT NULL,
    indepyear smallint,
    population integer NOT NULL,
    lifeexpectancy real,
    gnp numeric(10,2),
    gnpold numeric(10,2),
    localname text NOT NULL,
    governmentform text NOT NULL,
    headofstate text,
    capital integer,
    code2 character(2) NOT NULL,
    CONSTRAINT country_continent_check CHECK ((((((((continent = 'Asia'::text) OR (continent = 'Europe'::text)) OR (continent = 'North America'::text)) OR (continent = 'Africa'::text)) OR (continent = 'Oceania'::text)) OR (continent = 'Antarctica'::text)) OR (continent = 'South America'::text)))
);


ALTER TABLE world.country OWNER TO "DB_Manager";

--
-- Name: countrylanguage; Type: TABLE; Schema: world; Owner: DB_Manager; Tablespace: 
--

CREATE TABLE countrylanguage (
    countrycode character(3) NOT NULL,
    language text NOT NULL,
    isofficial boolean NOT NULL,
    percentage real NOT NULL
);


ALTER TABLE world.countrylanguage OWNER TO "DB_Manager";

SET search_path = booktown, pg_catalog;

--
-- Data for Name: alternate_stock; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY alternate_stock (isbn, cost, retail, stock) FROM stdin;
\.
COPY alternate_stock (isbn, cost, retail, stock) FROM '$$PATH$$/2218.dat';

--
-- Name: author_ids; Type: SEQUENCE SET; Schema: booktown; Owner: postgres
--

SELECT pg_catalog.setval('author_ids', 25044, true);


--
-- Data for Name: authors; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY authors (id, last_name, first_name) FROM stdin;
\.
COPY authors (id, last_name, first_name) FROM '$$PATH$$/2220.dat';

--
-- Data for Name: book_backup; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY book_backup (id, title, author_id, subject_id) FROM stdin;
\.
COPY book_backup (id, title, author_id, subject_id) FROM '$$PATH$$/2221.dat';

--
-- Name: book_ids; Type: SEQUENCE SET; Schema: booktown; Owner: postgres
--

SELECT pg_catalog.setval('book_ids', 41478, true);


--
-- Data for Name: book_queue; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY book_queue (title, author_id, subject_id, approved) FROM stdin;
\.
COPY book_queue (title, author_id, subject_id, approved) FROM '$$PATH$$/2223.dat';

--
-- Data for Name: books; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY books (id, title, author_id, subject_id) FROM stdin;
\.
COPY books (id, title, author_id, subject_id) FROM '$$PATH$$/2224.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY customers (id, last_name, first_name) FROM stdin;
\.
COPY customers (id, last_name, first_name) FROM '$$PATH$$/2225.dat';

--
-- Data for Name: daily_inventory; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY daily_inventory (isbn, is_stocked) FROM stdin;
\.
COPY daily_inventory (isbn, is_stocked) FROM '$$PATH$$/2226.dat';

--
-- Data for Name: distinguished_authors; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY distinguished_authors (id, last_name, first_name, award) FROM stdin;
\.
COPY distinguished_authors (id, last_name, first_name, award) FROM '$$PATH$$/2227.dat';

--
-- Data for Name: editions; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY editions (isbn, book_id, edition, publisher_id, publication, type) FROM stdin;
\.
COPY editions (isbn, book_id, edition, publisher_id, publication, type) FROM '$$PATH$$/2228.dat';

--
-- Data for Name: employees; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY employees (id, last_name, first_name) FROM stdin;
\.
COPY employees (id, last_name, first_name) FROM '$$PATH$$/2229.dat';

--
-- Data for Name: favorite_authors; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY favorite_authors (employee_id, authors_and_titles) FROM stdin;
\.
COPY favorite_authors (employee_id, authors_and_titles) FROM '$$PATH$$/2230.dat';

--
-- Data for Name: favorite_books; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY favorite_books (employee_id, books) FROM stdin;
\.
COPY favorite_books (employee_id, books) FROM '$$PATH$$/2231.dat';

--
-- Data for Name: money_example; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY money_example (money_cash, numeric_cash) FROM stdin;
\.
COPY money_example (money_cash, numeric_cash) FROM '$$PATH$$/2232.dat';

--
-- Data for Name: my_list; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY my_list (todos) FROM stdin;
\.
COPY my_list (todos) FROM '$$PATH$$/2233.dat';

--
-- Data for Name: numeric_values; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY numeric_values (num) FROM stdin;
\.
COPY numeric_values (num) FROM '$$PATH$$/2234.dat';

--
-- Data for Name: publishers; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY publishers (id, name, address) FROM stdin;
\.
COPY publishers (id, name, address) FROM '$$PATH$$/2235.dat';

--
-- Data for Name: schedules; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY schedules (employee_id, schedule) FROM stdin;
\.
COPY schedules (employee_id, schedule) FROM '$$PATH$$/2237.dat';

--
-- Data for Name: shipments; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY shipments (id, customer_id, isbn, ship_date) FROM stdin;
\.
COPY shipments (id, customer_id, isbn, ship_date) FROM '$$PATH$$/2236.dat';

--
-- Name: shipments_ship_id_seq; Type: SEQUENCE SET; Schema: booktown; Owner: postgres
--

SELECT pg_catalog.setval('shipments_ship_id_seq', 1011, true);


--
-- Data for Name: states; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY states (id, name, abbreviation) FROM stdin;
\.
COPY states (id, name, abbreviation) FROM '$$PATH$$/2239.dat';

--
-- Data for Name: stock; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY stock (isbn, cost, retail, stock) FROM stdin;
\.
COPY stock (isbn, cost, retail, stock) FROM '$$PATH$$/2240.dat';

--
-- Data for Name: stock_backup; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY stock_backup (isbn, cost, retail, stock) FROM stdin;
\.
COPY stock_backup (isbn, cost, retail, stock) FROM '$$PATH$$/2241.dat';

--
-- Name: subject_ids; Type: SEQUENCE SET; Schema: booktown; Owner: postgres
--

SELECT pg_catalog.setval('subject_ids', 15, true);


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY subjects (id, subject, location) FROM stdin;
\.
COPY subjects (id, subject, location) FROM '$$PATH$$/2243.dat';

--
-- Data for Name: text_sorting; Type: TABLE DATA; Schema: booktown; Owner: DB_Manager
--

COPY text_sorting (letter) FROM stdin;
\.
COPY text_sorting (letter) FROM '$$PATH$$/2244.dat';

SET search_path = company, pg_catalog;

--
-- Data for Name: department; Type: TABLE DATA; Schema: company; Owner: DB_Manager
--

COPY department (name, id, manager_ssn, manager_start_date) FROM stdin;
\.
COPY department (name, id, manager_ssn, manager_start_date) FROM '$$PATH$$/2245.dat';

--
-- Data for Name: department_location; Type: TABLE DATA; Schema: company; Owner: DB_Manager
--

COPY department_location (department_id, location) FROM stdin;
\.
COPY department_location (department_id, location) FROM '$$PATH$$/2246.dat';

--
-- Data for Name: dependent; Type: TABLE DATA; Schema: company; Owner: DB_Manager
--

COPY dependent (employee_ssn, name, sex, birthdate, relationship) FROM stdin;
\.
COPY dependent (employee_ssn, name, sex, birthdate, relationship) FROM '$$PATH$$/2247.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: company; Owner: DB_Manager
--

COPY employee (first_name, middle_initial, last_name, ssn, birthdate, address, sex, salary, manager_ssn, department_id) FROM stdin;
\.
COPY employee (first_name, middle_initial, last_name, ssn, birthdate, address, sex, salary, manager_ssn, department_id) FROM '$$PATH$$/2248.dat';

--
-- Data for Name: project; Type: TABLE DATA; Schema: company; Owner: DB_Manager
--

COPY project (name, id, location, department_id) FROM stdin;
\.
COPY project (name, id, location, department_id) FROM '$$PATH$$/2249.dat';

--
-- Data for Name: works_on; Type: TABLE DATA; Schema: company; Owner: DB_Manager
--

COPY works_on (employee_ssn, project_id, hours) FROM stdin;
\.
COPY works_on (employee_ssn, project_id, hours) FROM '$$PATH$$/2250.dat';

SET search_path = jobs, pg_catalog;

--
-- Data for Name: adminuser; Type: TABLE DATA; Schema: jobs; Owner: DB_Manager
--

COPY adminuser (email, lastlogin) FROM stdin;
\.
COPY adminuser (email, lastlogin) FROM '$$PATH$$/2258.dat';

--
-- Data for Name: employer; Type: TABLE DATA; Schema: jobs; Owner: DB_Manager
--

COPY employer (empname) FROM stdin;
\.
COPY employer (empname) FROM '$$PATH$$/2259.dat';

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: jobs; Owner: DB_Manager
--

COPY jobs (empname, email, jobtitle) FROM stdin;
\.
COPY jobs (empname, email, jobtitle) FROM '$$PATH$$/2260.dat';

--
-- Data for Name: regularuser; Type: TABLE DATA; Schema: jobs; Owner: DB_Manager
--

COPY regularuser (email, birthdate, sex, hometown, currentcity) FROM stdin;
\.
COPY regularuser (email, birthdate, sex, hometown, currentcity) FROM '$$PATH$$/2261.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: jobs; Owner: DB_Manager
--

COPY "user" (email, password, username) FROM stdin;
\.
COPY "user" (email, password, username) FROM '$$PATH$$/2262.dat';

SET search_path = sales, pg_catalog;

--
-- Data for Name: customers; Type: TABLE DATA; Schema: sales; Owner: postgres
--

COPY customers ("CUST_NUM", "COMPANY", "CUST_REP", "CREDIT_LIMIT") FROM stdin;
\.
COPY customers ("CUST_NUM", "COMPANY", "CUST_REP", "CREDIT_LIMIT") FROM '$$PATH$$/2251.dat';

--
-- Data for Name: offices; Type: TABLE DATA; Schema: sales; Owner: DB_Manager
--

COPY offices ("OFFICE", "CITY", "REGION", "MGR") FROM stdin;
\.
COPY offices ("OFFICE", "CITY", "REGION", "MGR") FROM '$$PATH$$/2252.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: sales; Owner: postgres
--

COPY orders ("ORDER_NUM", "ORDER_DATE", "CUST", "AMOUNT") FROM stdin;
\.
COPY orders ("ORDER_NUM", "ORDER_DATE", "CUST", "AMOUNT") FROM '$$PATH$$/2253.dat';

--
-- Data for Name: salesreps; Type: TABLE DATA; Schema: sales; Owner: postgres
--

COPY salesreps ("EMPL_NUM", "NAME", "AGE", "REP_OFFICE", "TITLE") FROM stdin;
\.
COPY salesreps ("EMPL_NUM", "NAME", "AGE", "REP_OFFICE", "TITLE") FROM '$$PATH$$/2254.dat';

SET search_path = world, pg_catalog;

--
-- Data for Name: city; Type: TABLE DATA; Schema: world; Owner: DB_Manager
--

COPY city (id, name, countrycode, district, population) FROM stdin;
\.
COPY city (id, name, countrycode, district, population) FROM '$$PATH$$/2255.dat';

--
-- Data for Name: country; Type: TABLE DATA; Schema: world; Owner: DB_Manager
--

COPY country (code, name, continent, region, surfacearea, indepyear, population, lifeexpectancy, gnp, gnpold, localname, governmentform, headofstate, capital, code2) FROM stdin;
\.
COPY country (code, name, continent, region, surfacearea, indepyear, population, lifeexpectancy, gnp, gnpold, localname, governmentform, headofstate, capital, code2) FROM '$$PATH$$/2256.dat';

--
-- Data for Name: countrylanguage; Type: TABLE DATA; Schema: world; Owner: DB_Manager
--

COPY countrylanguage (countrycode, language, isofficial, percentage) FROM stdin;
\.
COPY countrylanguage (countrycode, language, isofficial, percentage) FROM '$$PATH$$/2257.dat';

SET search_path = booktown, pg_catalog;

--
-- Name: authors_pkey; Type: CONSTRAINT; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (id);


--
-- Name: books_id_pkey; Type: CONSTRAINT; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY books
    ADD CONSTRAINT books_id_pkey PRIMARY KEY (id);


--
-- Name: customers_pkey; Type: CONSTRAINT; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: employees_pkey; Type: CONSTRAINT; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: pkey; Type: CONSTRAINT; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY editions
    ADD CONSTRAINT pkey PRIMARY KEY (isbn);


--
-- Name: publishers_pkey; Type: CONSTRAINT; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY publishers
    ADD CONSTRAINT publishers_pkey PRIMARY KEY (id);


--
-- Name: schedules_pkey; Type: CONSTRAINT; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY schedules
    ADD CONSTRAINT schedules_pkey PRIMARY KEY (employee_id);


--
-- Name: state_pkey; Type: CONSTRAINT; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY states
    ADD CONSTRAINT state_pkey PRIMARY KEY (id);


--
-- Name: stock_pkey; Type: CONSTRAINT; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY stock
    ADD CONSTRAINT stock_pkey PRIMARY KEY (isbn);


--
-- Name: subjects_pkey; Type: CONSTRAINT; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


SET search_path = company, pg_catalog;

--
-- Name: department_id_pkey; Type: CONSTRAINT; Schema: company; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY department
    ADD CONSTRAINT department_id_pkey PRIMARY KEY (id);


--
-- Name: department_location_id_location_pkey; Type: CONSTRAINT; Schema: company; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY department_location
    ADD CONSTRAINT department_location_id_location_pkey PRIMARY KEY (location, department_id);


--
-- Name: department_name_key; Type: CONSTRAINT; Schema: company; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY department
    ADD CONSTRAINT department_name_key UNIQUE (name);


--
-- Name: dependent_ssn_name_pkey; Type: CONSTRAINT; Schema: company; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY dependent
    ADD CONSTRAINT dependent_ssn_name_pkey PRIMARY KEY (employee_ssn, name);


--
-- Name: employee_ssn_pkey; Type: CONSTRAINT; Schema: company; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT employee_ssn_pkey PRIMARY KEY (ssn);


--
-- Name: project_id_pkey; Type: CONSTRAINT; Schema: company; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_id_pkey PRIMARY KEY (id);


--
-- Name: project_name_key; Type: CONSTRAINT; Schema: company; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_name_key UNIQUE (name);


--
-- Name: works_on_ssn_id_pkey; Type: CONSTRAINT; Schema: company; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY works_on
    ADD CONSTRAINT works_on_ssn_id_pkey PRIMARY KEY (project_id, employee_ssn);


SET search_path = jobs, pg_catalog;

--
-- Name: jobs_adminuser_pk; Type: CONSTRAINT; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY adminuser
    ADD CONSTRAINT jobs_adminuser_pk PRIMARY KEY (email);


--
-- Name: jobs_employer_pk; Type: CONSTRAINT; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY employer
    ADD CONSTRAINT jobs_employer_pk PRIMARY KEY (empname);


--
-- Name: jobs_jobs_pk; Type: CONSTRAINT; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY jobs
    ADD CONSTRAINT jobs_jobs_pk PRIMARY KEY (empname, email, jobtitle);


--
-- Name: jobs_regularuser_pk; Type: CONSTRAINT; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY regularuser
    ADD CONSTRAINT jobs_regularuser_pk PRIMARY KEY (email);


--
-- Name: jobs_user_pk; Type: CONSTRAINT; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT jobs_user_pk PRIMARY KEY (email);


SET search_path = sales, pg_catalog;

--
-- Name: cust_num_pkey; Type: CONSTRAINT; Schema: sales; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY customers
    ADD CONSTRAINT cust_num_pkey PRIMARY KEY ("CUST_NUM");


--
-- Name: office_pkey; Type: CONSTRAINT; Schema: sales; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY offices
    ADD CONSTRAINT office_pkey PRIMARY KEY ("OFFICE");


--
-- Name: order_num_pkey; Type: CONSTRAINT; Schema: sales; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT order_num_pkey PRIMARY KEY ("ORDER_NUM");


--
-- Name: salesreps_pkey; Type: CONSTRAINT; Schema: sales; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY salesreps
    ADD CONSTRAINT salesreps_pkey PRIMARY KEY ("EMPL_NUM");


SET search_path = world, pg_catalog;

--
-- Name: city_pkey; Type: CONSTRAINT; Schema: world; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY city
    ADD CONSTRAINT city_pkey PRIMARY KEY (id);


--
-- Name: country_pkey; Type: CONSTRAINT; Schema: world; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_pkey PRIMARY KEY (code);


--
-- Name: countrylanguage_pkey; Type: CONSTRAINT; Schema: world; Owner: DB_Manager; Tablespace: 
--

ALTER TABLE ONLY countrylanguage
    ADD CONSTRAINT countrylanguage_pkey PRIMARY KEY (countrycode, language);


SET search_path = booktown, pg_catalog;

--
-- Name: books_title_idx; Type: INDEX; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE INDEX books_title_idx ON books USING btree (title);


--
-- Name: shipments_ship_id_key; Type: INDEX; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE UNIQUE INDEX shipments_ship_id_key ON shipments USING btree (id);


--
-- Name: text_idx; Type: INDEX; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE INDEX text_idx ON text_sorting USING btree (letter);


--
-- Name: unique_publisher_idx; Type: INDEX; Schema: booktown; Owner: DB_Manager; Tablespace: 
--

CREATE UNIQUE INDEX unique_publisher_idx ON publishers USING btree (name);


SET search_path = jobs, pg_catalog;

--
-- Name: fki_jobs_jobs_fk_employer; Type: INDEX; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

CREATE INDEX fki_jobs_jobs_fk_employer ON jobs USING btree (empname);


--
-- Name: fki_jobs_jobs_fk_regularuser; Type: INDEX; Schema: jobs; Owner: DB_Manager; Tablespace: 
--

CREATE INDEX fki_jobs_jobs_fk_regularuser ON jobs USING btree (email);


SET search_path = sales, pg_catalog;

--
-- Name: fki_cust_num_fkey; Type: INDEX; Schema: sales; Owner: postgres; Tablespace: 
--

CREATE INDEX fki_cust_num_fkey ON orders USING btree ("CUST");


--
-- Name: fki_rep_office_fkey; Type: INDEX; Schema: sales; Owner: postgres; Tablespace: 
--

CREATE INDEX fki_rep_office_fkey ON salesreps USING btree ("REP_OFFICE");


SET search_path = booktown, pg_catalog;

--
-- Name: sync_stock_with_editions; Type: RULE; Schema: booktown; Owner: DB_Manager
--

CREATE RULE sync_stock_with_editions AS ON UPDATE TO editions DO UPDATE stock SET isbn = new.isbn WHERE (stock.isbn = old.isbn);


--
-- Name: check_shipment; Type: TRIGGER; Schema: booktown; Owner: DB_Manager
--

CREATE TRIGGER check_shipment BEFORE INSERT OR UPDATE ON shipments FOR EACH ROW EXECUTE PROCEDURE check_shipment_addition();


--
-- Name: sync_authors_books; Type: TRIGGER; Schema: booktown; Owner: DB_Manager
--

CREATE TRIGGER sync_authors_books BEFORE UPDATE ON authors FOR EACH ROW EXECUTE PROCEDURE sync_authors_and_books();


--
-- Name: valid_employee; Type: FK CONSTRAINT; Schema: booktown; Owner: DB_Manager
--

ALTER TABLE ONLY schedules
    ADD CONSTRAINT valid_employee FOREIGN KEY (employee_id) REFERENCES employees(id) MATCH FULL;


SET search_path = company, pg_catalog;

--
-- Name: department_location_department_id_fkey; Type: FK CONSTRAINT; Schema: company; Owner: DB_Manager
--

ALTER TABLE ONLY department_location
    ADD CONSTRAINT department_location_department_id_fkey FOREIGN KEY (department_id) REFERENCES department(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: department_manager_ssn_fkey; Type: FK CONSTRAINT; Schema: company; Owner: DB_Manager
--

ALTER TABLE ONLY department
    ADD CONSTRAINT department_manager_ssn_fkey FOREIGN KEY (manager_ssn) REFERENCES employee(ssn) ON UPDATE CASCADE ON DELETE SET DEFAULT;


--
-- Name: dependent_employee_ssn_fkey; Type: FK CONSTRAINT; Schema: company; Owner: DB_Manager
--

ALTER TABLE ONLY dependent
    ADD CONSTRAINT dependent_employee_ssn_fkey FOREIGN KEY (employee_ssn) REFERENCES employee(ssn);


--
-- Name: employee_department_id_fkey; Type: FK CONSTRAINT; Schema: company; Owner: DB_Manager
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT employee_department_id_fkey FOREIGN KEY (department_id) REFERENCES department(id) ON UPDATE SET DEFAULT ON DELETE CASCADE;


--
-- Name: employee_manager_ssn_fkey; Type: FK CONSTRAINT; Schema: company; Owner: DB_Manager
--

ALTER TABLE ONLY employee
    ADD CONSTRAINT employee_manager_ssn_fkey FOREIGN KEY (manager_ssn) REFERENCES employee(ssn) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: project_department_id_fkey; Type: FK CONSTRAINT; Schema: company; Owner: DB_Manager
--

ALTER TABLE ONLY project
    ADD CONSTRAINT project_department_id_fkey FOREIGN KEY (department_id) REFERENCES department(id);


--
-- Name: works_on_employee_ssn_fkey; Type: FK CONSTRAINT; Schema: company; Owner: DB_Manager
--

ALTER TABLE ONLY works_on
    ADD CONSTRAINT works_on_employee_ssn_fkey FOREIGN KEY (employee_ssn) REFERENCES employee(ssn);


--
-- Name: works_on_project_id_fkey; Type: FK CONSTRAINT; Schema: company; Owner: DB_Manager
--

ALTER TABLE ONLY works_on
    ADD CONSTRAINT works_on_project_id_fkey FOREIGN KEY (project_id) REFERENCES project(id);


SET search_path = sales, pg_catalog;

--
-- Name: cust_num_fkey; Type: FK CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY orders
    ADD CONSTRAINT cust_num_fkey FOREIGN KEY ("CUST") REFERENCES customers("CUST_NUM");


--
-- Name: empl_cust_num_fkey; Type: FK CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY customers
    ADD CONSTRAINT empl_cust_num_fkey FOREIGN KEY ("CUST_NUM") REFERENCES salesreps("EMPL_NUM");


--
-- Name: rep_office_fkey; Type: FK CONSTRAINT; Schema: sales; Owner: postgres
--

ALTER TABLE ONLY salesreps
    ADD CONSTRAINT rep_office_fkey FOREIGN KEY ("REP_OFFICE") REFERENCES offices("OFFICE");


SET search_path = world, pg_catalog;

--
-- Name: country_capital_fkey; Type: FK CONSTRAINT; Schema: world; Owner: DB_Manager
--

ALTER TABLE ONLY country
    ADD CONSTRAINT country_capital_fkey FOREIGN KEY (capital) REFERENCES city(id);


--
-- Name: countrylanguage_countrycode_fkey; Type: FK CONSTRAINT; Schema: world; Owner: DB_Manager
--

ALTER TABLE ONLY countrylanguage
    ADD CONSTRAINT countrylanguage_countrycode_fkey FOREIGN KEY (countrycode) REFERENCES country(code);


--
-- Name: booktown; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA booktown FROM PUBLIC;
REVOKE ALL ON SCHEMA booktown FROM postgres;
GRANT ALL ON SCHEMA booktown TO postgres;
GRANT USAGE ON SCHEMA booktown TO readonly;


--
-- Name: company; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA company FROM PUBLIC;
REVOKE ALL ON SCHEMA company FROM postgres;
GRANT ALL ON SCHEMA company TO postgres;
GRANT USAGE ON SCHEMA company TO readonly;


--
-- Name: jobs; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA jobs FROM PUBLIC;
GRANT ALL ON SCHEMA jobs TO readonly;


--
-- Name: public; Type: ACL; Schema: -; Owner: readonly
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM readonly;
GRANT ALL ON SCHEMA public TO readonly;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: sales; Type: ACL; Schema: -; Owner: DB_Manager
--

REVOKE ALL ON SCHEMA sales FROM PUBLIC;
REVOKE ALL ON SCHEMA sales FROM "DB_Manager";
GRANT ALL ON SCHEMA sales TO "DB_Manager";
GRANT USAGE ON SCHEMA sales TO readonly;


--
-- Name: world; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA world FROM PUBLIC;
REVOKE ALL ON SCHEMA world FROM postgres;
GRANT ALL ON SCHEMA world TO postgres;
GRANT USAGE ON SCHEMA world TO readonly;


SET search_path = booktown, pg_catalog;

--
-- Name: add_shipment(integer, text); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION add_shipment(integer, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION add_shipment(integer, text) FROM postgres;
GRANT ALL ON FUNCTION add_shipment(integer, text) TO postgres;
GRANT ALL ON FUNCTION add_shipment(integer, text) TO PUBLIC;


--
-- Name: add_two_loop(integer, integer); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION add_two_loop(integer, integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION add_two_loop(integer, integer) FROM postgres;
GRANT ALL ON FUNCTION add_two_loop(integer, integer) TO postgres;
GRANT ALL ON FUNCTION add_two_loop(integer, integer) TO PUBLIC;


--
-- Name: audit_test(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION audit_test() FROM PUBLIC;
REVOKE ALL ON FUNCTION audit_test() FROM postgres;
GRANT ALL ON FUNCTION audit_test() TO postgres;
GRANT ALL ON FUNCTION audit_test() TO PUBLIC;


--
-- Name: books_by_subject(text); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION books_by_subject(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION books_by_subject(text) FROM postgres;
GRANT ALL ON FUNCTION books_by_subject(text) TO postgres;
GRANT ALL ON FUNCTION books_by_subject(text) TO PUBLIC;


--
-- Name: check_book_addition(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION check_book_addition() FROM PUBLIC;
REVOKE ALL ON FUNCTION check_book_addition() FROM postgres;
GRANT ALL ON FUNCTION check_book_addition() TO postgres;
GRANT ALL ON FUNCTION check_book_addition() TO PUBLIC;


--
-- Name: check_shipment_addition(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION check_shipment_addition() FROM PUBLIC;
REVOKE ALL ON FUNCTION check_shipment_addition() FROM postgres;
GRANT ALL ON FUNCTION check_shipment_addition() TO postgres;
GRANT ALL ON FUNCTION check_shipment_addition() TO PUBLIC;


--
-- Name: compound_word(text, text); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION compound_word(text, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION compound_word(text, text) FROM postgres;
GRANT ALL ON FUNCTION compound_word(text, text) TO postgres;
GRANT ALL ON FUNCTION compound_word(text, text) TO PUBLIC;


--
-- Name: count_by_two(integer); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION count_by_two(integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION count_by_two(integer) FROM postgres;
GRANT ALL ON FUNCTION count_by_two(integer) TO postgres;
GRANT ALL ON FUNCTION count_by_two(integer) TO PUBLIC;


--
-- Name: double_price(double precision); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION double_price(double precision) FROM PUBLIC;
REVOKE ALL ON FUNCTION double_price(double precision) FROM postgres;
GRANT ALL ON FUNCTION double_price(double precision) TO postgres;
GRANT ALL ON FUNCTION double_price(double precision) TO PUBLIC;


--
-- Name: extract_all_titles(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION extract_all_titles() FROM PUBLIC;
REVOKE ALL ON FUNCTION extract_all_titles() FROM postgres;
GRANT ALL ON FUNCTION extract_all_titles() TO postgres;
GRANT ALL ON FUNCTION extract_all_titles() TO PUBLIC;


--
-- Name: extract_all_titles2(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION extract_all_titles2() FROM PUBLIC;
REVOKE ALL ON FUNCTION extract_all_titles2() FROM postgres;
GRANT ALL ON FUNCTION extract_all_titles2() TO postgres;
GRANT ALL ON FUNCTION extract_all_titles2() TO PUBLIC;


--
-- Name: extract_title(integer); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION extract_title(integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION extract_title(integer) FROM postgres;
GRANT ALL ON FUNCTION extract_title(integer) TO postgres;
GRANT ALL ON FUNCTION extract_title(integer) TO PUBLIC;


--
-- Name: first(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION first() FROM PUBLIC;
REVOKE ALL ON FUNCTION first() FROM postgres;
GRANT ALL ON FUNCTION first() TO postgres;
GRANT ALL ON FUNCTION first() TO PUBLIC;


--
-- Name: get_author(text); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION get_author(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION get_author(text) FROM postgres;
GRANT ALL ON FUNCTION get_author(text) TO postgres;
GRANT ALL ON FUNCTION get_author(text) TO PUBLIC;


--
-- Name: get_author(integer); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION get_author(integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION get_author(integer) FROM postgres;
GRANT ALL ON FUNCTION get_author(integer) TO postgres;
GRANT ALL ON FUNCTION get_author(integer) TO PUBLIC;


--
-- Name: get_customer_id(text, text); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION get_customer_id(text, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION get_customer_id(text, text) FROM postgres;
GRANT ALL ON FUNCTION get_customer_id(text, text) TO postgres;
GRANT ALL ON FUNCTION get_customer_id(text, text) TO PUBLIC;


--
-- Name: get_customer_name(integer); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION get_customer_name(integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION get_customer_name(integer) FROM postgres;
GRANT ALL ON FUNCTION get_customer_name(integer) TO postgres;
GRANT ALL ON FUNCTION get_customer_name(integer) TO PUBLIC;


--
-- Name: givename(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION givename() FROM PUBLIC;
REVOKE ALL ON FUNCTION givename() FROM postgres;
GRANT ALL ON FUNCTION givename() TO postgres;
GRANT ALL ON FUNCTION givename() TO PUBLIC;


--
-- Name: html_linebreaks(text); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION html_linebreaks(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION html_linebreaks(text) FROM postgres;
GRANT ALL ON FUNCTION html_linebreaks(text) TO postgres;
GRANT ALL ON FUNCTION html_linebreaks(text) TO PUBLIC;


--
-- Name: in_stock(integer, integer); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION in_stock(integer, integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION in_stock(integer, integer) FROM postgres;
GRANT ALL ON FUNCTION in_stock(integer, integer) TO postgres;
GRANT ALL ON FUNCTION in_stock(integer, integer) TO PUBLIC;


--
-- Name: isbn_to_title(text); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION isbn_to_title(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION isbn_to_title(text) FROM postgres;
GRANT ALL ON FUNCTION isbn_to_title(text) TO postgres;
GRANT ALL ON FUNCTION isbn_to_title(text) TO PUBLIC;


--
-- Name: mixed(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION mixed() FROM PUBLIC;
REVOKE ALL ON FUNCTION mixed() FROM postgres;
GRANT ALL ON FUNCTION mixed() TO postgres;
GRANT ALL ON FUNCTION mixed() TO PUBLIC;


--
-- Name: raise_test(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION raise_test() FROM PUBLIC;
REVOKE ALL ON FUNCTION raise_test() FROM postgres;
GRANT ALL ON FUNCTION raise_test() TO postgres;
GRANT ALL ON FUNCTION raise_test() TO PUBLIC;


--
-- Name: ship_item(text, text, text); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION ship_item(text, text, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION ship_item(text, text, text) FROM postgres;
GRANT ALL ON FUNCTION ship_item(text, text, text) TO postgres;
GRANT ALL ON FUNCTION ship_item(text, text, text) TO PUBLIC;


--
-- Name: stock_amount(integer, integer); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION stock_amount(integer, integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION stock_amount(integer, integer) FROM postgres;
GRANT ALL ON FUNCTION stock_amount(integer, integer) TO postgres;
GRANT ALL ON FUNCTION stock_amount(integer, integer) TO PUBLIC;


--
-- Name: sync_authors_and_books(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION sync_authors_and_books() FROM PUBLIC;
REVOKE ALL ON FUNCTION sync_authors_and_books() FROM postgres;
GRANT ALL ON FUNCTION sync_authors_and_books() TO postgres;
GRANT ALL ON FUNCTION sync_authors_and_books() TO PUBLIC;


--
-- Name: test(integer); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION test(integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION test(integer) FROM postgres;
GRANT ALL ON FUNCTION test(integer) TO postgres;
GRANT ALL ON FUNCTION test(integer) TO PUBLIC;


--
-- Name: test_check_a_id(); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION test_check_a_id() FROM PUBLIC;
REVOKE ALL ON FUNCTION test_check_a_id() FROM postgres;
GRANT ALL ON FUNCTION test_check_a_id() TO postgres;
GRANT ALL ON FUNCTION test_check_a_id() TO PUBLIC;


--
-- Name: title(integer); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION title(integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION title(integer) FROM postgres;
GRANT ALL ON FUNCTION title(integer) TO postgres;
GRANT ALL ON FUNCTION title(integer) TO PUBLIC;


--
-- Name: triple_price(double precision); Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON FUNCTION triple_price(double precision) FROM PUBLIC;
REVOKE ALL ON FUNCTION triple_price(double precision) FROM postgres;
GRANT ALL ON FUNCTION triple_price(double precision) TO postgres;
GRANT ALL ON FUNCTION triple_price(double precision) TO PUBLIC;


--
-- Name: alternate_stock; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE alternate_stock FROM PUBLIC;
REVOKE ALL ON TABLE alternate_stock FROM "DB_Manager";
GRANT ALL ON TABLE alternate_stock TO "DB_Manager";
GRANT SELECT ON TABLE alternate_stock TO readonly;


--
-- Name: author_ids; Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON SEQUENCE author_ids FROM PUBLIC;
REVOKE ALL ON SEQUENCE author_ids FROM postgres;
GRANT ALL ON SEQUENCE author_ids TO postgres;
GRANT SELECT ON SEQUENCE author_ids TO readonly;


--
-- Name: authors; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE authors FROM PUBLIC;
REVOKE ALL ON TABLE authors FROM "DB_Manager";
GRANT ALL ON TABLE authors TO "DB_Manager";
GRANT SELECT ON TABLE authors TO readonly;


--
-- Name: book_backup; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE book_backup FROM PUBLIC;
REVOKE ALL ON TABLE book_backup FROM "DB_Manager";
GRANT ALL ON TABLE book_backup TO "DB_Manager";
GRANT SELECT ON TABLE book_backup TO readonly;


--
-- Name: book_ids; Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON SEQUENCE book_ids FROM PUBLIC;
REVOKE ALL ON SEQUENCE book_ids FROM postgres;
GRANT ALL ON SEQUENCE book_ids TO postgres;
GRANT SELECT ON SEQUENCE book_ids TO readonly;


--
-- Name: book_queue; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE book_queue FROM PUBLIC;
REVOKE ALL ON TABLE book_queue FROM "DB_Manager";
GRANT ALL ON TABLE book_queue TO "DB_Manager";
GRANT SELECT ON TABLE book_queue TO readonly;


--
-- Name: books; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE books FROM PUBLIC;
REVOKE ALL ON TABLE books FROM "DB_Manager";
GRANT ALL ON TABLE books TO "DB_Manager";
GRANT SELECT ON TABLE books TO readonly;


--
-- Name: customers; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE customers FROM PUBLIC;
REVOKE ALL ON TABLE customers FROM "DB_Manager";
GRANT ALL ON TABLE customers TO "DB_Manager";
GRANT SELECT ON TABLE customers TO readonly;


--
-- Name: daily_inventory; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE daily_inventory FROM PUBLIC;
REVOKE ALL ON TABLE daily_inventory FROM "DB_Manager";
GRANT ALL ON TABLE daily_inventory TO "DB_Manager";
GRANT SELECT ON TABLE daily_inventory TO readonly;


--
-- Name: distinguished_authors; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE distinguished_authors FROM PUBLIC;
REVOKE ALL ON TABLE distinguished_authors FROM "DB_Manager";
GRANT ALL ON TABLE distinguished_authors TO "DB_Manager";
GRANT SELECT ON TABLE distinguished_authors TO readonly;


--
-- Name: editions; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE editions FROM PUBLIC;
REVOKE ALL ON TABLE editions FROM "DB_Manager";
GRANT ALL ON TABLE editions TO "DB_Manager";
GRANT SELECT ON TABLE editions TO readonly;


--
-- Name: employees; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE employees FROM PUBLIC;
REVOKE ALL ON TABLE employees FROM "DB_Manager";
GRANT ALL ON TABLE employees TO "DB_Manager";
GRANT SELECT ON TABLE employees TO readonly;


--
-- Name: favorite_authors; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE favorite_authors FROM PUBLIC;
REVOKE ALL ON TABLE favorite_authors FROM "DB_Manager";
GRANT ALL ON TABLE favorite_authors TO "DB_Manager";
GRANT SELECT ON TABLE favorite_authors TO readonly;


--
-- Name: favorite_books; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE favorite_books FROM PUBLIC;
REVOKE ALL ON TABLE favorite_books FROM "DB_Manager";
GRANT ALL ON TABLE favorite_books TO "DB_Manager";
GRANT SELECT ON TABLE favorite_books TO readonly;


--
-- Name: money_example; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE money_example FROM PUBLIC;
REVOKE ALL ON TABLE money_example FROM "DB_Manager";
GRANT ALL ON TABLE money_example TO "DB_Manager";
GRANT SELECT ON TABLE money_example TO readonly;


--
-- Name: my_list; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE my_list FROM PUBLIC;
REVOKE ALL ON TABLE my_list FROM "DB_Manager";
GRANT ALL ON TABLE my_list TO "DB_Manager";
GRANT SELECT ON TABLE my_list TO readonly;


--
-- Name: numeric_values; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE numeric_values FROM PUBLIC;
REVOKE ALL ON TABLE numeric_values FROM "DB_Manager";
GRANT ALL ON TABLE numeric_values TO "DB_Manager";
GRANT SELECT ON TABLE numeric_values TO readonly;


--
-- Name: publishers; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE publishers FROM PUBLIC;
REVOKE ALL ON TABLE publishers FROM "DB_Manager";
GRANT ALL ON TABLE publishers TO "DB_Manager";
GRANT SELECT ON TABLE publishers TO readonly;


--
-- Name: shipments; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE shipments FROM PUBLIC;
REVOKE ALL ON TABLE shipments FROM "DB_Manager";
GRANT ALL ON TABLE shipments TO "DB_Manager";
GRANT SELECT ON TABLE shipments TO readonly;


--
-- Name: recent_shipments; Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON TABLE recent_shipments FROM PUBLIC;
REVOKE ALL ON TABLE recent_shipments FROM postgres;
GRANT ALL ON TABLE recent_shipments TO postgres;
GRANT SELECT ON TABLE recent_shipments TO readonly;


--
-- Name: schedules; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE schedules FROM PUBLIC;
REVOKE ALL ON TABLE schedules FROM "DB_Manager";
GRANT ALL ON TABLE schedules TO "DB_Manager";
GRANT SELECT ON TABLE schedules TO readonly;


--
-- Name: shipments_ship_id_seq; Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON SEQUENCE shipments_ship_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE shipments_ship_id_seq FROM postgres;
GRANT ALL ON SEQUENCE shipments_ship_id_seq TO postgres;
GRANT SELECT ON SEQUENCE shipments_ship_id_seq TO readonly;


--
-- Name: states; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE states FROM PUBLIC;
REVOKE ALL ON TABLE states FROM "DB_Manager";
GRANT ALL ON TABLE states TO "DB_Manager";
GRANT SELECT ON TABLE states TO readonly;


--
-- Name: stock; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE stock FROM PUBLIC;
REVOKE ALL ON TABLE stock FROM "DB_Manager";
GRANT ALL ON TABLE stock TO "DB_Manager";
GRANT SELECT ON TABLE stock TO readonly;


--
-- Name: stock_backup; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE stock_backup FROM PUBLIC;
REVOKE ALL ON TABLE stock_backup FROM "DB_Manager";
GRANT ALL ON TABLE stock_backup TO "DB_Manager";
GRANT SELECT ON TABLE stock_backup TO readonly;


--
-- Name: stock_view; Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON TABLE stock_view FROM PUBLIC;
REVOKE ALL ON TABLE stock_view FROM postgres;
GRANT ALL ON TABLE stock_view TO postgres;
GRANT SELECT ON TABLE stock_view TO readonly;


--
-- Name: subject_ids; Type: ACL; Schema: booktown; Owner: postgres
--

REVOKE ALL ON SEQUENCE subject_ids FROM PUBLIC;
REVOKE ALL ON SEQUENCE subject_ids FROM postgres;
GRANT ALL ON SEQUENCE subject_ids TO postgres;
GRANT SELECT ON SEQUENCE subject_ids TO readonly;


--
-- Name: subjects; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE subjects FROM PUBLIC;
REVOKE ALL ON TABLE subjects FROM "DB_Manager";
GRANT ALL ON TABLE subjects TO "DB_Manager";
GRANT SELECT ON TABLE subjects TO readonly;


--
-- Name: text_sorting; Type: ACL; Schema: booktown; Owner: DB_Manager
--

REVOKE ALL ON TABLE text_sorting FROM PUBLIC;
REVOKE ALL ON TABLE text_sorting FROM "DB_Manager";
GRANT ALL ON TABLE text_sorting TO "DB_Manager";
GRANT SELECT ON TABLE text_sorting TO readonly;


SET search_path = company, pg_catalog;

--
-- Name: department; Type: ACL; Schema: company; Owner: DB_Manager
--

REVOKE ALL ON TABLE department FROM PUBLIC;
REVOKE ALL ON TABLE department FROM "DB_Manager";
GRANT ALL ON TABLE department TO "DB_Manager";
GRANT SELECT ON TABLE department TO readonly;
GRANT ALL ON TABLE department TO postgres;


--
-- Name: department_location; Type: ACL; Schema: company; Owner: DB_Manager
--

REVOKE ALL ON TABLE department_location FROM PUBLIC;
REVOKE ALL ON TABLE department_location FROM "DB_Manager";
GRANT ALL ON TABLE department_location TO "DB_Manager";
GRANT SELECT ON TABLE department_location TO readonly;
GRANT ALL ON TABLE department_location TO postgres;


--
-- Name: dependent; Type: ACL; Schema: company; Owner: DB_Manager
--

REVOKE ALL ON TABLE dependent FROM PUBLIC;
REVOKE ALL ON TABLE dependent FROM "DB_Manager";
GRANT ALL ON TABLE dependent TO "DB_Manager";
GRANT SELECT ON TABLE dependent TO readonly;
GRANT ALL ON TABLE dependent TO postgres;


--
-- Name: employee; Type: ACL; Schema: company; Owner: DB_Manager
--

REVOKE ALL ON TABLE employee FROM PUBLIC;
REVOKE ALL ON TABLE employee FROM "DB_Manager";
GRANT ALL ON TABLE employee TO "DB_Manager";
GRANT SELECT ON TABLE employee TO readonly;
GRANT ALL ON TABLE employee TO postgres;


--
-- Name: project; Type: ACL; Schema: company; Owner: DB_Manager
--

REVOKE ALL ON TABLE project FROM PUBLIC;
REVOKE ALL ON TABLE project FROM "DB_Manager";
GRANT ALL ON TABLE project TO "DB_Manager";
GRANT SELECT ON TABLE project TO readonly;
GRANT ALL ON TABLE project TO postgres;


--
-- Name: works_on; Type: ACL; Schema: company; Owner: DB_Manager
--

REVOKE ALL ON TABLE works_on FROM PUBLIC;
REVOKE ALL ON TABLE works_on FROM "DB_Manager";
GRANT ALL ON TABLE works_on TO "DB_Manager";
GRANT SELECT ON TABLE works_on TO readonly;
GRANT ALL ON TABLE works_on TO postgres;


SET search_path = jobs, pg_catalog;

--
-- Name: adminuser; Type: ACL; Schema: jobs; Owner: DB_Manager
--

REVOKE ALL ON TABLE adminuser FROM PUBLIC;
REVOKE ALL ON TABLE adminuser FROM "DB_Manager";
GRANT ALL ON TABLE adminuser TO "DB_Manager";
GRANT SELECT ON TABLE adminuser TO readonly;


--
-- Name: employer; Type: ACL; Schema: jobs; Owner: DB_Manager
--

REVOKE ALL ON TABLE employer FROM PUBLIC;
REVOKE ALL ON TABLE employer FROM "DB_Manager";
GRANT ALL ON TABLE employer TO "DB_Manager";
GRANT SELECT ON TABLE employer TO readonly;


--
-- Name: jobs; Type: ACL; Schema: jobs; Owner: DB_Manager
--

REVOKE ALL ON TABLE jobs FROM PUBLIC;
REVOKE ALL ON TABLE jobs FROM "DB_Manager";
GRANT ALL ON TABLE jobs TO "DB_Manager";
GRANT SELECT ON TABLE jobs TO readonly;


--
-- Name: regularuser; Type: ACL; Schema: jobs; Owner: DB_Manager
--

REVOKE ALL ON TABLE regularuser FROM PUBLIC;
REVOKE ALL ON TABLE regularuser FROM "DB_Manager";
GRANT ALL ON TABLE regularuser TO "DB_Manager";
GRANT SELECT ON TABLE regularuser TO readonly;


--
-- Name: user; Type: ACL; Schema: jobs; Owner: DB_Manager
--

REVOKE ALL ON TABLE "user" FROM PUBLIC;
REVOKE ALL ON TABLE "user" FROM "DB_Manager";
GRANT ALL ON TABLE "user" TO "DB_Manager";
GRANT SELECT ON TABLE "user" TO readonly;


SET search_path = sales, pg_catalog;

--
-- Name: customers; Type: ACL; Schema: sales; Owner: postgres
--

REVOKE ALL ON TABLE customers FROM PUBLIC;
REVOKE ALL ON TABLE customers FROM postgres;
GRANT ALL ON TABLE customers TO postgres;
GRANT SELECT ON TABLE customers TO readonly;


--
-- Name: offices; Type: ACL; Schema: sales; Owner: DB_Manager
--

REVOKE ALL ON TABLE offices FROM PUBLIC;
REVOKE ALL ON TABLE offices FROM "DB_Manager";
GRANT ALL ON TABLE offices TO "DB_Manager";
GRANT SELECT ON TABLE offices TO readonly;


--
-- Name: orders; Type: ACL; Schema: sales; Owner: postgres
--

REVOKE ALL ON TABLE orders FROM PUBLIC;
REVOKE ALL ON TABLE orders FROM postgres;
GRANT ALL ON TABLE orders TO postgres;
GRANT SELECT ON TABLE orders TO readonly;


--
-- Name: salesreps; Type: ACL; Schema: sales; Owner: postgres
--

REVOKE ALL ON TABLE salesreps FROM PUBLIC;
REVOKE ALL ON TABLE salesreps FROM postgres;
GRANT ALL ON TABLE salesreps TO postgres;
GRANT SELECT ON TABLE salesreps TO readonly;


SET search_path = world, pg_catalog;

--
-- Name: city; Type: ACL; Schema: world; Owner: DB_Manager
--

REVOKE ALL ON TABLE city FROM PUBLIC;
REVOKE ALL ON TABLE city FROM "DB_Manager";
GRANT ALL ON TABLE city TO "DB_Manager";
GRANT SELECT ON TABLE city TO readonly;


--
-- Name: country; Type: ACL; Schema: world; Owner: DB_Manager
--

REVOKE ALL ON TABLE country FROM PUBLIC;
REVOKE ALL ON TABLE country FROM "DB_Manager";
GRANT ALL ON TABLE country TO "DB_Manager";
GRANT SELECT ON TABLE country TO readonly;


--
-- Name: countrylanguage; Type: ACL; Schema: world; Owner: DB_Manager
--

REVOKE ALL ON TABLE countrylanguage FROM PUBLIC;
REVOKE ALL ON TABLE countrylanguage FROM "DB_Manager";
GRANT ALL ON TABLE countrylanguage TO "DB_Manager";
GRANT SELECT ON TABLE countrylanguage TO readonly;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TABLES  TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT SELECT ON TABLES  TO readonly;


SET search_path = company, pg_catalog;

--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: company; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA company REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA company REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA company GRANT SELECT ON TABLES  TO readonly;


SET search_path = jobs, pg_catalog;

--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: jobs; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA jobs REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA jobs REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA jobs GRANT SELECT ON TABLES  TO readonly;


SET search_path = sales, pg_catalog;

--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: sales; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sales REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sales REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA sales GRANT SELECT ON TABLES  TO readonly;


SET search_path = world, pg_catalog;

--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: world; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA world REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA world REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA world GRANT SELECT ON TABLES  TO readonly;


--
-- PostgreSQL database dump complete
--

